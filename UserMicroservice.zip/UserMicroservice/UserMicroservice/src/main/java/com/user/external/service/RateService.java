//package com.user.external.service;
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import com.user.entity.Rate;
//
//@FeignClient(name = "RATE-SERVICE")
//public interface RateService {
//
//	@GetMapping("/rating/user/{userId}")
//	Rate getRate(@PathVariable String userId);
//
//}
